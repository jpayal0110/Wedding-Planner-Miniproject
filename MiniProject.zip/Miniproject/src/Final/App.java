package Final;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;


public class App {

  public static void main(String[] args) throws IOException {
    boolean isOver = false;
    Event event = new Event();
    Scanner s = new Scanner(System.in);
    String passWord; 
    String userName = "user";
    String adminName ="admin";
    String adminPassword="admin123"; 
    String userPassword="user123"; 

    BufferedReader br=new BufferedReader(new InputStreamReader(System.in)); 
        System.out.println("*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*==WEDDING PLANNING SYSTEM==*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*"); //login procedure 
        while (true)
        { 
            System.out.print("\nLog in as: (admin/user/quit):"); 
            userName=br.readLine(); 
            if(userName.equals("user") || adminName.equals("admin") )
            {
                System.out.print("");
            }  
            else 
            {
                System.out.print("Illegal LoginName");
            }
            
            System.out.print("Password:");
            passWord=br.readLine(); 
            if(passWord.equals(userPassword) || passWord.equals(adminPassword))
                break;
            else
            {
                System.out.println("Illegal password");
            }
        }
    System.out.println("\n*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
    System.out.println("\nWelcome to wedding Management!!!!\n");
    System.out.println("Please enter Wedding date as such MM/DD/YYYY");
    String date= s.nextLine();
    System.out.println("\nWhat would you like to plan first?");
   
    while(!isOver) {
      boolean isDoneWithFood = false;
      boolean isDoneWithDrinks = false;
      boolean isDoneWithEntertainment = false;
      //boolean isDoneWithDecoration = false;
      boolean isDoneWithPrice = false;
      System.out.println("Type: \n-guests \n-food \n-drinks \n-entertainment \n-price \n-print \n-quit \n");
      
      String choice = s.nextLine();
        switch (choice) {
            case "quit": 
                System.out.println("Thanks, have a good day!");
                isOver = true;
                System.out.println("*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
                break;
                
            case "guests":
                System.out.println("\n*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*== Guests ==*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
                System.out.println("Type the number of guests attending.");
                int guestAmount = Integer.parseInt(s.nextLine());
                event.setNumberOfGuests(guestAmount);
                System.out.println("Thanks, " + guestAmount + " guests are attending.\n");
                System.out.println("*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
                break;
            case "food":
                System.out.println("\n*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*== Food ==*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
                while(!isDoneWithFood) {
                    System.out.println("\nType 'a' to add a food,'r' to remove a food,'p' to print current drinks,'b' to return to the main option menu.");
                    String foodChoice = s.nextLine();
                    
          switch (foodChoice) {
              case "a":
                  System.out.println("\nWhat type of meal would you like?");
                  String foodToAdd = s.nextLine();
                  event.setFood(foodToAdd);
                  System.out.println(foodToAdd + ", was added to the list.");
                  break;
              case "r":
                  System.out.println("Here's a list of our items so far.");
                  event.printFood();
                  System.out.println("Type the number for the item you would like to remove.");
                  int foodToRemove = Integer.parseInt(s.nextLine());
                  event.removeFood(foodToRemove);
                  System.out.println(foodToRemove + ", was removed from the list.");
                  break;
              case "b":
                  System.out.println("Thanks, choose another option.");
                  isDoneWithFood = true;
                  System.out.println("*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
                  break;
              case "p":
                  if (event.getAmountOfFood() == 0) {
                      System.out.println("Sorry, nothing to print. \n");
                  } else {
                      event.printFood();
                  }
                  break;
              default:
                  System.out.println("Invalid input");
                  break;
          }
                }       break;
            case "drinks":
                System.out.println("\n*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*== Drinks ==*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
                while(!isDoneWithDrinks) {
                    System.out.println("Type 'a' to add a drink, 'r' to remove a drink, 'p' to print current drinks, or 'b' to return to the main option menu.");
                    String drinkChoice = s.nextLine();
                    
          switch (drinkChoice) {
              case "a":
                  System.out.println("What type of drink would you like");
                  String drinkToAdd = s.nextLine();
                  event.setDrink(drinkToAdd);
                  System.out.println(drinkToAdd + ", was added to the list.");
                  break;
              case "r":
                  System.out.println("Here's a list of our items so far.");
                  event.printDrinks();
                  System.out.println("Type the number for the item you would like to remove.");
                  int drinkToRemove = Integer.parseInt(s.nextLine());
                  event.removeDrink(drinkToRemove);
                  System.out.println("Drink item #" + drinkToRemove + " , was removed from the list.");
                  break;
              case "b":
                  System.out.println("Thanks, choose another option.");
                  isDoneWithDrinks = true;
                   System.out.println("*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*==");
                  break;
              case "p":
                  if (event.getAmountOfDrinks() == 0) {
                      System.out.println("Sorry, nothing to print. \n");
                  } else {
                      event.printDrinks();
                  }
                  break;
              default:
                  System.out.println("Invalid input");
                  break;
          }
                }       break;
                
            case "entertainment":
                System.out.println("\n*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*== Entertainment ==*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
                System.out.println("What entertainment do you want?");
                System.out.println("Type 'music', 'comedian', or 'other'.");
                String eChoice = s.nextLine();
      switch (eChoice) {
          case "music":
              System.out.println("We have three choices for music. Type 'rock', 'rap', or 'DJ'.");
              String musicChoice = s.nextLine();
              event.setEntertainment(musicChoice);
              System.out.println("Thanks, you choose " + musicChoice);
              System.out.println("*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
              break;
          case "comedian":
              System.out.println("We have two choices for comedians. Type 'Dave' for Dave Chappelle' or 'Kevin' for Kevin Hart.");
              String comedianChoice = s.nextLine();
              event.setEntertainment(comedianChoice);
              System.out.println("Thanks, you choose " + comedianChoice);
              System.out.println("*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
              break;
          case "other":
              System.out.println("Alright, type whatever entertainment you want and will try to get them.");
              String otherEntertainmentChoice = s.nextLine();
              event.setEntertainment(otherEntertainmentChoice);
              System.out.println("Thanks, you choose " + otherEntertainmentChoice);
              System.out.println("*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
              break;
          default:
              System.out.println("Invalid input");
              break;
      }
break;

         
            case "print":
                event.printDetails();
                break;
            case "price":
                int totalPrice;
                System.out.println("\n*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*== Price ==*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
                while(!isDoneWithPrice) {
                    System.out.println("For specific pricing type 'food', 'drinks', or 'entertainment'. For total price type 'all'. Type 'back' to return to the main option menu.");
                    String priceChoice = s.nextLine();
          switch (priceChoice) {
              case "food":
                  totalPrice = event.getPrice(priceChoice);
                  System.out.println("Food Total: " + "Rs." + totalPrice);
                  break;
              case "drinks":
                  totalPrice = event.getPrice(priceChoice);
                  System.out.println("Drinks Total: " + "Rs." + totalPrice);
                  break;
              case "entertainment":
                  totalPrice = event.getPrice(priceChoice);
                  System.out.println("Entertainment Total: " + "Rs." + totalPrice);
                  break;
              case "all":
                  totalPrice = event.getPrice(priceChoice);
                  System.out.println("Complete Total: " + "Rs." + totalPrice);
                  break;
              case "back":
                  System.out.println("Thanks, choose another option.");
                  isDoneWithPrice = true;
                   System.out.println("*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*");
                  break;
              default:
                  System.out.println("Invalid Input.");
                  break;
          }
                }       break;
            default:
                System.out.println("Invalid Input.");
                break;
        }
    }
  }
}
